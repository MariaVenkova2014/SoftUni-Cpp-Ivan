/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std; 

int main()
{ // moje da se otpechata kato chislo 
    std::cout<< 1 << endl; 
    std::cout<< 2 << endl;
    std::cout<< 3 << endl;
    std::cout<< 4 << endl;
    std::cout<< 5 << endl;
    std::cout<< 6 << endl; 
    std::cout<< 7 << endl;
    std::cout<< 8 << endl;
    std::cout<< 9 << endl;
    std::cout<< 10 << endl;

    return 0;
}