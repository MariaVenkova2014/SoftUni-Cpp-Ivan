
#include <iostream>

using namespace std;


int main()
{
    // Константи
   const double DOG_FOOD_PRICE = 2.50;
   const double CAT_FOOD_PRICE = 4;
   
   // Променливи:
   
   int dogFoodCount, catFoodCount;
   cin >> dogFoodCount >> catFoodCount;
   
   // Пресмятаме единична цена
   
   double totalDogsFoodPrice = dogFoodCount * DOG_FOOD_PRICE;
   double totalCatsFoodPrice = catFoodCount * CAT_FOOD_PRICE;
   
   // Пресмятаме обща цена
   
   double totalPrice = totalDogsFoodPrice + totalCatsFoodPrice;
   
   // Печатаме краен резултат
   
   cout << totalPrice << " lv.";

    return 0;
}



//{крайната сума} lv.