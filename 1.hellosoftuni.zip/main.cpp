
#include <iostream>

int main() { // funkcia, Cpp tarsi za tazi funkcia!

    std::cout << "Hello SoftUni"; // std e standartnata biblioteka / nameSpace prostranstvo ot promenlivi
    
    return 0; // funciata si e prekluchila rabota i wrashtamme cqlo chislo 0 - !
    
}