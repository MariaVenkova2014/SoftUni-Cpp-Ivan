/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using std::cout;
using std::endl;
using std::string;


int main()
{
    
    string name = "Pesho";
    int edge = 30;
    float weight1 = 98.8; // zakraglia do drugo chislo
    double weight2 = 100.1;
    char initials = 'p';
    
    cout << name << " " << edge << " " << weight1 << " " << weight2 << " " << initials;
    // shte raboti i s edinichni kawichki, no samo za edin interval

    return 0;
}